﻿namespace SeatGeek.Service.Data.Models.Event
{
  
    public class AllEventsFilteredAndPagedServiceModel
    {
    //    public AllEventsFilteredAndPagedServiceModel()
    //    {
    //        this.Events = new HashSet<EventsAllViewModel>();
    //    }

    //    public int TotalHousesCount { get; set; }

    //    public IEnumerable<HouseAllViewModel> Houses { get; set; }

    }
}
