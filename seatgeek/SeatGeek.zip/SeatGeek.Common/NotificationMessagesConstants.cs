﻿namespace SeatGeek.Common
{
    public static class NotificationMessagesConstants
    {
        public const string ErrorMessage = "ErrorMessage";
        public const string WarningMessage = "WarnMessage";
        public const string InformationMessage = "InfoMessage";
        public const string SuccessMessage = "SuccessMessage";
    }
}
