﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeatGeek.Common
{
    public class GeneralValidationConstants
    {
        public const int DefaultPage =1;
        public const int EntitiesPerPage = 3;
    }
}
