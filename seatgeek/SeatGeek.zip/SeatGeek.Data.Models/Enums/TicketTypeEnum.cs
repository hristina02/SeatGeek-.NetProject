﻿namespace SeatGeek.Data.Models.Enums
{
    public enum TicketTypeEnum
    {
        Gold = 1,
        Silver = 2,
        Bronze=3
    }
}
